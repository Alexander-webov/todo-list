-- Реферальная программа
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS referral_code TEXT UNIQUE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS referred_by UUID REFERENCES profiles(id);
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS trial_used BOOLEAN DEFAULT FALSE;

-- Генерируем реферальные коды для существующих пользователей
UPDATE profiles SET referral_code = LOWER(SUBSTRING(MD5(id::text), 1, 8))
WHERE referral_code IS NULL;

-- Триггер: автоматически генерировать реферальный код при регистрации
CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.referral_code IS NULL THEN
    NEW.referral_code := LOWER(SUBSTRING(MD5(NEW.id::text), 1, 8));
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_referral_code ON profiles;
CREATE TRIGGER set_referral_code
  BEFORE INSERT ON profiles
  FOR EACH ROW EXECUTE FUNCTION generate_referral_code();

-- Статистика сайта (кэшируем чтобы не считать каждый раз)
CREATE TABLE IF NOT EXISTS site_stats (
  key   TEXT PRIMARY KEY,
  value NUMERIC DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO site_stats (key, value) VALUES
  ('total_projects_found', 0),
  ('premium_users_today', 0)
ON CONFLICT (key) DO NOTHING;

-- schema-v7-posting-queue.sql
-- Очередь постинга в Telegram + настройки из админки + лог

-- ─── 1. Очередь ───
CREATE TABLE IF NOT EXISTS posting_queue (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  source TEXT NOT NULL,
  category TEXT,
  title TEXT NOT NULL,
  target_channel TEXT NOT NULL,           -- 'ru' | 'int'
  telegram_text TEXT NOT NULL,            -- готовый текст поста
  score NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending', -- pending | posted | skipped | failed
  posted_at TIMESTAMPTZ,
  posted_message_id BIGINT,
  error_msg TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(project_id, target_channel)
);

CREATE INDEX IF NOT EXISTS idx_queue_pending_score
  ON posting_queue (target_channel, score DESC, created_at ASC)
  WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS idx_queue_created ON posting_queue (created_at);

-- ─── 2. Настройки (одна строка) ───
CREATE TABLE IF NOT EXISTS telegram_settings (
  id INT PRIMARY KEY DEFAULT 1,
  is_enabled BOOLEAN NOT NULL DEFAULT true,
  posts_per_hour INT NOT NULL DEFAULT 5,          -- общий лимит на оба канала
  min_score NUMERIC NOT NULL DEFAULT 10,          -- фильтр мусора из очереди
  max_queue_age_hours INT NOT NULL DEFAULT 6,     -- старые проекты протухают
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (id = 1)
);

INSERT INTO telegram_settings (id) VALUES (1) ON CONFLICT DO NOTHING;

-- ─── 3. Лог публикаций (для статистики админки) ───
CREATE TABLE IF NOT EXISTS telegram_posts_log (
  id BIGSERIAL PRIMARY KEY,
  queue_id UUID REFERENCES posting_queue(id) ON DELETE SET NULL,
  target_channel TEXT,
  source TEXT,
  category TEXT,
  score NUMERIC,
  posted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_log_posted_at ON telegram_posts_log (posted_at DESC);

-- ============================================================
-- Schema v2 — Auth, Premium, Payments
-- Выполни в Supabase > SQL Editor
-- ============================================================

CREATE TABLE IF NOT EXISTS profiles (
  id               UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email            TEXT,
  is_premium       BOOLEAN   DEFAULT FALSE,
  premium_until    TIMESTAMPTZ,
  is_admin         BOOLEAN   DEFAULT FALSE,
  telegram_chat_id TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email)
  VALUES (NEW.id, NEW.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

CREATE TABLE IF NOT EXISTS payments (
  id               UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id          UUID        REFERENCES profiles(id) ON DELETE CASCADE,
  provider         TEXT        NOT NULL,
  provider_id      TEXT        UNIQUE,
  amount           NUMERIC     NOT NULL,
  currency         TEXT        NOT NULL,
  status           TEXT        DEFAULT 'pending',
  days_granted     INT         DEFAULT 30,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  confirmed_at     TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS premium_gifts (
  id               UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  admin_id         UUID        REFERENCES profiles(id),
  user_id          UUID        REFERENCES profiles(id) ON DELETE CASCADE,
  days             INT         NOT NULL,
  note             TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION activate_premium(p_user_id UUID, p_days INT)
RETURNS VOID AS $$
DECLARE
  current_end TIMESTAMPTZ;
BEGIN
  SELECT premium_until INTO current_end FROM profiles WHERE id = p_user_id;
  UPDATE profiles SET
    is_premium = TRUE,
    premium_until = GREATEST(NOW(), COALESCE(current_end, NOW())) + (p_days || ' days')::INTERVAL
  WHERE id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE premium_gifts ENABLE ROW LEVEL SECURITY;

-- Удаляем старые политики если существуют, потом создаём заново
DO $$ BEGIN
  DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
  DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
  DROP POLICY IF EXISTS "Users can read own payments" ON payments;
  DROP POLICY IF EXISTS "Service role full access profiles" ON profiles;
  DROP POLICY IF EXISTS "Service role full access payments" ON payments;
  DROP POLICY IF EXISTS "Service role full access gifts" ON premium_gifts;
END $$;

CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can read own payments"
  ON payments FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Service role full access profiles"
  ON profiles FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY "Service role full access payments"
  ON payments FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY "Service role full access gifts"
  ON premium_gifts FOR ALL USING (auth.role() = 'service_role');

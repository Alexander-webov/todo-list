-- schema-v6-upwork.sql
-- Добавляет счётчик последнего запуска Upwork парсера

INSERT INTO site_stats (key, value) VALUES
  ('upwork_last_scrape', 0)
ON CONFLICT (key) DO NOTHING;

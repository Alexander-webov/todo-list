-- schema-v5-ads.sql
-- Таблица рекламных объявлений

CREATE TABLE IF NOT EXISTS ads (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  image_url TEXT,
  link TEXT NOT NULL,
  position TEXT NOT NULL DEFAULT 'feed', -- 'feed' | 'sidebar' | 'telegram' | 'all'
  is_active BOOLEAN DEFAULT true,
  priority INT DEFAULT 0,
  clicks INT DEFAULT 0,
  views INT DEFAULT 0,
  -- Telegram-размещение
  tg_pin_hours INT DEFAULT 2,       -- сколько часов после публикации НЕ постить другие посты
  tg_keep_hours INT DEFAULT 48,     -- через сколько часов удалить пост из канала
  tg_posted_at TIMESTAMPTZ,         -- когда опубликован в канал
  tg_message_id BIGINT,             -- ID сообщения в канале (для удаления)
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Счётчик для рекламы в Telegram (каждый N-й пост — реклама)
INSERT INTO site_stats (key, value) VALUES
  ('telegram_channel_post_count', 0)
ON CONFLICT (key) DO NOTHING;

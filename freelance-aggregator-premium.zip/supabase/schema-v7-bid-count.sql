-- ============================================================
-- schema-v7-bid-count.sql
-- Добавляем счётчик откликов к проектам для "счётчика конкуренции"
-- ============================================================

ALTER TABLE projects
  ADD COLUMN IF NOT EXISTS bid_count INTEGER,
  ADD COLUMN IF NOT EXISTS bid_count_updated_at TIMESTAMPTZ;

-- Индекс для фильтрации "горячих" проектов (0 откликов + свежие)
CREATE INDEX IF NOT EXISTS idx_projects_bid_count ON projects (bid_count);

-- Композитный индекс для сортировки "горячих" на главной (опционально)
CREATE INDEX IF NOT EXISTS idx_projects_hot
  ON projects (bid_count, published_at DESC)
  WHERE bid_count IS NOT NULL;

COMMENT ON COLUMN projects.bid_count IS 'Количество откликов на бирже. NULL = биржа не даёт эту информацию (напр. FL.ru RSS).';
COMMENT ON COLUMN projects.bid_count_updated_at IS 'Когда последний раз обновляли bid_count. Нужно чтобы показывать "обновлено N минут назад" и решать, пересчитывать ли.';

'use client';
import { useState } from 'react';
import { createBrowserClient } from '@supabase/ssr';
import { useRouter } from 'next/navigation';
import styles from './dashboard.module.css';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';

export function DashboardClient({ profile, email, payments, paymentStatus }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [chatId, setChatId] = useState(profile?.telegram_chat_id || '');
  const [tgLoading, setTgLoading] = useState(false);
  const [tgResult, setTgResult] = useState(null);

  async function logout() {
    setLoading(true);
    const supabase = createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
    );
    await supabase.auth.signOut();
    router.push('/');
    router.refresh();
  }

  async function connectTelegram(e) {
    e.preventDefault();
    setTgLoading(true);
    setTgResult(null);
    try {
      const res = await fetch('/api/telegram/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId }),
      });
      const data = await res.json();
      setTgResult(data.success
        ? { ok: true, msg: '✅ Telegram подключён! Проверь сообщение от бота.' }
        : { ok: false, msg: data.error });
    } catch {
      setTgResult({ ok: false, msg: 'Ошибка соединения' });
    } finally {
      setTgLoading(false);
    }
  }

  const isPremium = profile?.is_premium && profile?.premium_until
    ? new Date(profile.premium_until) > new Date()
    : false;

  const premiumUntil = profile?.premium_until
    ? format(new Date(profile.premium_until), 'd MMMM yyyy', { locale: ru })
    : null;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <a href="/" className={styles.back}>← Назад</a>
        <button className={styles.logoutBtn} onClick={logout} disabled={loading}>
          {loading ? '...' : 'Выйти'}
        </button>
      </div>

      {paymentStatus === 'success' && (
        <div className={styles.successBanner}>
          🎉 Оплата прошла успешно! Премиум активирован.
        </div>
      )}

      <div className={styles.section}>
        <h1 className={styles.sectionTitle}>Мой аккаунт</h1>
        <div className={styles.card}>
          <div className={styles.row}>
            <span className={styles.rowLabel}>Email</span>
            <span className={styles.rowValue}>{email}</span>
          </div>
          <div className={styles.row}>
            <span className={styles.rowLabel}>Статус</span>
            <span className={`${styles.rowValue} ${isPremium ? styles.premium : styles.free}`}>
              {isPremium ? '⚡ Премиум' : '🔒 Бесплатный'}
            </span>
          </div>
          {isPremium && premiumUntil && (
            <div className={styles.row}>
              <span className={styles.rowLabel}>Активен до</span>
              <span className={styles.rowValue}>{premiumUntil}</span>
            </div>
          )}
        </div>
      </div>

      {!isPremium && (
        <div className={styles.section}>
          <a href="/pricing" className={styles.upgradeBtn}>
            ⚡ Получить Премиум — от 299 ₽/мес
          </a>
        </div>
      )}

      {isPremium && (
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Telegram уведомления</h2>
          <div className={styles.card} style={{ padding: '18px' }}>
            <p className={styles.tgDesc}>
              Получай новые проекты прямо в Telegram как только они появятся.
            </p>
            <ol className={styles.tgSteps}>
              <li>Открой бота и отправь /start — он пришлёт твой Chat ID</li>
              <li>Вставь Chat ID ниже и нажми «Подключить»</li>
            </ol>
            <form className={styles.tgForm} onSubmit={connectTelegram}>
              <input
                type="text" className={styles.tgInput}
                placeholder="Твой Chat ID (например: 123456789)"
                value={chatId} onChange={e => setChatId(e.target.value)} required
              />
              <button type="submit" className={styles.tgBtn} disabled={tgLoading}>
                {tgLoading ? '...' : profile?.telegram_chat_id ? 'Обновить' : 'Подключить'}
              </button>
            </form>
            {tgResult && (
              <p className={`${styles.tgResult} ${tgResult.ok ? styles.tgOk : styles.tgErr}`}>
                {tgResult.msg}
              </p>
            )}
          </div>
        </div>
      )}

      {payments.length > 0 && (
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>История платежей</h2>
          <div className={styles.card}>
            {payments.map(p => (
              <div key={p.id} className={styles.paymentRow}>
                <div>
                  <p className={styles.paymentName}>
                    {p.provider === 'yookassa' ? '🇷🇺 ЮKassa' : '🌍 Stripe'} · {p.days_granted} дней
                  </p>
                  <p className={styles.paymentDate}>
                    {format(new Date(p.created_at), 'd MMM yyyy', { locale: ru })}
                  </p>
                </div>
                <div className={styles.paymentRight}>
                  <span className={styles.paymentAmount}>
                    {p.currency === 'RUB' ? `${p.amount} ₽` : `$${p.amount}`}
                  </span>
                  <span className={`${styles.paymentStatus} ${p.status === 'succeeded' ? styles.statusOk : styles.statusPending}`}>
                    {p.status === 'succeeded' ? 'Оплачен' : 'Ожидает'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
